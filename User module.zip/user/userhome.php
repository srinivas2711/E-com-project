<html>
   <head>
   	  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <meta charset="UTF-8">
	  <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title> HOME </title>
	  <?php 
	    include("top.inc.php");
        $conn=mysqli_connect("localhost","root","","grocery");
        if(!$conn)
        {  
	        $msg="Unable to connect with Servers. Try again later!!";
	        die();
        }	  

	?>
	  <link rel="preconnect" href="https://fonts.gstatic.com">
	<style>

		.box 
		{
        margin-top: 20px;
        border: 2px solid #ffd9b3;
        width: 200px;
        height: 300px
		margin: 20px;
	   }
	   #top{
		 color: blue;
         font-size: 25px;		 
	   }
	   img{
         width: 150px;
         height: 170px;
         margin: 20px;
	   }
	   .rating{
         color: gold;
         margin-left: 20px;
         margin-top: -20px;
	   }
	   .title{
		  font-family: 'Staatliches', cursive;
    text-transform: uppercase;
    font-size: 25px;
    margin-left: 15px;
    color: darkblue; 
	   }
	   .price{
		   font-size: 20px;
           border: 2px solid blanchedalmond;
           background: #eee;
		   color: crimson;
	   }
	   #w{
		   text-decoration: line-through;
	   }
	   .offer{
		   margin-top: 10px;
           margin-left: 20px;
           margin-right: 20px;
           padding-left: 20px;
           font-size: 20px;
           border: 1px solid lightgrey;
           background: lightgray;
           color: darkgreen;
	   }
	   .btns{
    border: 2px solid snow;
    margin-right: 10px;
    border-radius: 10px;
    background: #CCFFCC;
    margin-left: 10px;
    margin-top: 5px;
	   }
	   #addcart{
		 width: 75px;
    height: 35px;
    margin-top: 20;
    margin-left: 10px;
    margin-bottom: 20px;
    background: #f7bb64;
    border-radius: 5px;
    font-size: 20px;
    font-family: -webkit-pictograph;
    color: red;

}
	  #addcart:hover, #buynow:hover{
		   background: #2d5ff5;
	   }
	   #buynow{
		width: 150px;
    height: 35px;
    margin-top: 20;
    margin-left: 10px;
    margin-bottom: 20px;
    background: #f7bb64;
    border-radius: 5px;
    font-size: 20px;
    font-family: -webkit-pictograph;
    color: green;  
	   }
	   #b:hover{
		   color: snow;
	   }
	   .btns:hover{
		   bacnkground: snow;
		   border: 1px red;
	   }
       .cart_div{
		   
	   } 
	   #car{
		   width:50px;
		   height:50px;
		   position:fixed;
		   top:60px;
		   left: 1230px;
	   }
	   #ca{
		   position: fixed;
    left: 1230px;
    top: 130px;
    font-size: 30px;
    font-family: fantasy;
    color: yellow;
    background: radial-gradient(black, transparent);  
	   }
	   #ref{
		   color:red;
	   }
	   #ref:hover{
		   color: snow;
	   }
		
  </style>
  
</head>
	<body>
       <?php
	   $cart_count=0;
         if(!empty($_SESSION["shopping_cart"])) 
		 {
            $cart_count = count(array_keys($_SESSION["shopping_cart"]));
		 }
        ?>
        <div class="cart_div">
           <a href="addcart.php"><img src="carting.jpg" id="car"><span id="ca">Cart
             <?php echo $cart_count; ?>!</span></a>
        </div>
	   <?php //include("slideshow.php");?>
       <table padding="20px">
	   <?php
	     	  $sql=mysqli_query($conn,"select * from product where product_status = 1 order by product_id asc ");
	          while($row=mysqli_fetch_assoc($sql))
	          {
			?>
	         <td>   
			    <div class="box">
	               <div class="offer"><b>15% offer <i class="far fa-badge-check"></i></b></div>
	                  <?php echo"<img src=uploads/$row[product_image] width=200px height=200px>"?> 
		              <div class="rating">
		                 <span><i class="fa fa-star" aria-hidden="true"></i></span>
		                 <span><i class="fa fa-star" aria-hidden="true"></i></span>
		                 <span><i class="fa fa-star" aria-hidden="true"></i></span>
		                 <span><i class="fa fa-star" aria-hidden="true"></i></span>
		                 <span><i class="fa fa-star" aria-hidden="true"></i></span>
                      </div>
	                  <div class="title"><?php echo $row["product_name"];?></div>
		              <div class="price">MRP:<span id="w">150 </span> <b> RS. <b> <?php echo $row["product_price"];?></div>
					  <form method="post" action="addcart.php?action=add&id=<?php echo $row["product_id"];?>"><div class="btns">
					     <button type="submit" name="addcart" id="addcart"value=""><span id="b"><i class="fas fa-shopping-cart"></i></span></button>
						 <input type="number" name="qty" id="qty" placeholder="QTY" min="1" max="10">
						 <input type="hidden" name="product_id" value="<?php echo $row["product_id"]?>">
					 </form>
					 <form method="post" action="page_description.php?action=add&id=<?php echo $row["product_id"];?>">
					  <button type="submit" name="Buynow" id="buynow"value="BUY NOW"><span id="ref">BUY NOW</span></button>
					  </form>
					 </div>
	          </div> 
            </td>
			<?php } ?>
        </tr>
      </table>
   </body>
</html>

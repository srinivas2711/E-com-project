<?php

include("top.inc.php");
$conn = mysqli_connect("localhost","root","","grocery");
if (!$conn){
    die("Database error");
}
$q=1;
$total_price = 0;
$tp = 0;
if(!isset($_SESSION))
   session_start();
$status="";
if(isset($_GET["id"])){
	 $code = mysqli_real_escape_string($conn,$_GET['id']);
    $result = mysqli_query($conn,"SELECT * FROM `product` WHERE Product_id='$code'");
    $row = mysqli_fetch_assoc($result);
    $name = $row['product_name'];
    $code = $row['product_id'];
    $price = $row['product_price'];
    $image = $row['product_image'];
    $q = $_POST["qty"];
    $cartArray = array($code=>
                array('name'=>$name,
                'code'=>$code,
                'price'=>$price,
                'quantity'=>$q,
                'image'=>$image));
    print_r($cartArray);
    if(isset($_POST["addcart"])){
        if(empty($_SESSION["shopping_cart"])) 
	     {
           $_SESSION["shopping_cart"] = $cartArray;
           $status = "<div class='box' style='color:green;'>Product is added to your cart!</div>";
         }
         if(isset($_SESSION["shopping_cart"])){

            $it=array_column($_SESSION["shopping_cart"],code);
            print_r($it);
            if(in_array($code,$it))
            {
               $status = "<div class='box' style='color:re;'>Product is already added to your cart!</div>";
            }
            else{
               $_SESSION["shopping_cart"] = array_merge($_SESSION["shopping_cart"],$cartArray);
               $status = "<div class='box' style='color:green;'>Product is added to your cart!</div>"; 
            }
         }
    }
   }
?>
<html>
  <head>
  </head>
  <style>
     table{
        background:snow;
        border-collapse:collapse;
        border:3px solid black;

     }
     tr:nth-child(odd){
background: thistle;
    font-size: 25px;
    font-family: system-ui;
     }
     tr:nth-child(even){
     background: white;
    font-size: 25px;
    font-family: system-ui;}
  </style>
  <body>
        <form method='post' action='#'>
			  <div class="rmvall">
               <input type="submit" name="removeall" value="removeall">
           </div>
         </form>
      <table>
         <tr>
           <td>IMAGE</td>
           <td>ITEM NAME</td>
           <td>QUANTITY</td>
           <td>UNIT PRICE</td>
           <td>ITEMS TOTAL</td>
        </tr> 
       <?php 
          if(isset($_SESSION["shopping_cart"])){
             foreach ($_SESSION["shopping_cart"] as $product){
       ?>
       <tr>
          <td><img src='<?php echo $product["image"];?>' width="50" height="40" /></td>
          <td><?php echo $product["name"]; ?></td>
          <td><?php echo $q;?> </td>
          <td><?php echo "Rs.",$product["price"]; ?></td>
          <td><?php $tp = $product["price"]*$product["quantity"];   echo "Rs.",$tp;?></td>
		  <td>
		      <form method='post' action='?action=?remove&id=<?php echo $product["code"];?>'>
			      <div class="rmv"><input type="submit" name="remove" value="remove"></div>

              </form>
		  </td>
       </tr>
       <?php
          $total_price += ($tp); 
        }
       ?>
       <tr>
         <td colspan="5" align="right"> <form method="post" action=""> <input type="submit" name="pay" value="TO PAY<?php echo "Rs.",$total_price; ?>"></form></td>
       </tr> 
    </table> 
     	<form method="post" action="userhome.php"> <input type="submit" name="pay" value="CONTINUE SHOPPING"></form>
      <div class="message_box" style="margin:10px 0px;">
          <?php echo $status; ?>
      </div>

<?php } 
if(isset($_POST["remove"]))
{
   $del_id=mysqli_real_escape_string($conn,$_GET["id"]);
   echo"$del_id";
   foreach($_SESSION["shopping_cart"] as $key=>$value)
   {
      if($value == $del_id){
         unset($_SESSION["shopping_cart"]["value"]);
      }
   }

}

if(isset($_POST["removeall"]))
{
   unset($_SESSION["shopping_cart"]);

}
if(isset($_POST["pay"]))
{ 
   if(isset($_SESSION["user"])){
      foreach($_SESSION["shopping_cart"] as $product){
      $a= $product["code"];
      $b= $product["name"];
      $c= date("Y.m.d");
      echo $c;
      $e=1;
      $s = 1;
      date_default_timezone_set("Asia/Calcutta");
      $d=date("H:i:s");
      echo $d;
      $p= 100.0;
      $s=mysqli_query($conn,"Insert into ordering_table(customer_id,product_id,price,ordering_time,ordering_date,ordering_status) 
      values('$e','$a','$p','$d','$c')");
      echo mysqli_error($conn);
   }
}
}
   ?>
      </body>
</html>

<html>
   <head>
   </head>
    <?php 	
      $conn=mysqli_connect("localhost","root","","grocery");
      if(!$conn)
	      die("unable to connect with servers"); 
      $sql=mysqli_query($conn,"Select ordering_id,product_id,quantity from ordering_table where ordering_status=1");
      while($row=mysqli_fetch_assoc($sql)){
        $oid = $row["ordering_id"];
        $pid=$row["product_id"];
        $q= $row["quantity"];
        echo $oid,$pid,$q;
        $sq="update product set product_quantity= product_quantity-$q where product_id=$pid";
        $result=mysqli_query($conn,$sq);
        echo mysqli_error($conn);
      }

      ?>

</html>
 <html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
  <?php
    session_start();
  ?>
  <style>
	*{
  padding: 0;
  margin: 0;
  text-decoration: none;
  list-style: none;
  box-sizing: border-box;
  text-select:none;
}
body{
  font-family: montserrat;
}
nav{
  background: #D66502;
  height: 80px;
  width: 100%;
}
label.logo{
  color: snow;
  font-size: 40px;
  line-height: 80px;
  padding: 0 100px;
  font-weight: bold;
}
nav ul{
  float: right;
  margin-right: 20px;
}
nav ul li{
  display: inline-block;
  line-height: 80px;
  margin: 0 5px;
}
nav ul li a{
  color: snow;
  font-size: 25px;
  font-family: Sans-serif;
  padding: 7px 13px;
  border-radius: 3px;
  text-transform: uppercase;
}
a:hover{
  background:snow;
  transition: .5s;
  color:blue;
}
.checkbtn{
  font-size: 30px;
  color: white;
  float: left;
  line-height: 80px;
  margin-top: 20px;
  margin-left:30px;
  cursor: pointer;
  display: none;
}
#check{
  display: none;
}
@media (max-width: 1200px){
  label.logo{
    font-size: 30px;
    padding-left: 50px;
  }
  nav ul li a{
    font-size: 16px;
  }
}
@media (max-width: 858px){
  .checkbtn{
    display: block;
  }
  ul{
    position: fixed;
    width: 100%;
    height: 100vh;
    background: #FFD9B3;
    top: 80px;
    left: -100%;
    text-align: center;
    transition: all .5s;
  }
  nav ul li{
    display: block;
    margin: 50px 0;
    line-height: 30px;
  }
  nav ul li a{
    font-size: 20px;
  }
  a:hover{
    background: none;
    color: blue;
  }
  #check:checked ~ ul{
    left: 0;
  }
}

.drpdwn a{
	color: midnightblue;
    font-family: cursive;
}
i.fa.fa-users{
  font-size:30px;
  color:snow;
}

</style>
  <body>
    <nav>
      <input type="checkbox" id="check">
      <label for="check" class="checkbtn">
        <i class="fas fa-bars"></i>
      </label>
      <label class="logo">My Grocery Shop</label>
      <ul>
	       <li><i class="fa fa-users" aria-hidden="true" size="10px"></i> <?php if(isset($_SESSION["user"])) 
                                                                       echo'  <script> window.alert("You are successfully logged in!");</script><a href="logout.php" id="logout" onclick="return("Are you going to logout?");">LOGOUT</a>';
                                                                  else
                                                                     echo'<script> window.alert("You are logged out!");</script><a href="log.php">LOGIN</a>';?></li>
        <li><a href="userhome.php">Home</a></li>
        <li><a href="?cs=1">Categories &#9662;</a></li> 
        <li><a href="#">Offers</a></li>
      </ul>
    </nav>
            <?php

			$conn=mysqli_connect("localhost","root","","grocery");
		     if(!$conn)
             {  
	             $msg="Unable to connect with Servers. Try again later!!";
	             die();
			 }
       		if(isset($_GET["cs"])) {
               $l=$_GET["cs"];
			   $c=mysqli_real_escape_string($conn,$l);
		    if(isset($c)&&($c == 1)){			 
			 $sql=mysqli_query($conn,"select category_name from categories where category_status=1 order by category_id");
             $n=mysqli_num_rows($sql);
			 if($n>0)
		     {
                ?>  
				
				<div class="drpdwn">
				<?php
					 $i=0;
				
	             while($row=mysqli_fetch_assoc($sql))
			     {
		           	 $a=array();
					 $a[$i]=$row["category_name"];
					 ?>
                      <li><a href="#"><?php  echo $a[$i],"\n";$i++;
					   ?></a></li>
			
			 <?php }?>
         			<a href="?cs=0" id="linkbk">back &#128473 </a><?php }?>
			 </div>
                       <style>
					      .drpdwn{
							display:block;
							text-transform: uppercase;
                            font-size: 20px;
                            font-family: system-ui;
                            background: #f5ede2;
                            width: 250px;
						    float: right;
							border-radius: 10px;
                            margin-right:140px;
                            padding: 20px;	
                            color: black;
                            position: relative;	
                            margin-top: 5px;							
              							
						  }
						  .drpdwn li a:hover{
							  background: orange;
							  color:white;
							  border: 2px snow;
							  border-radius: 5px;
						  }
						  #linkbk{
							  color: red;
							  position: relative;
							  float:right;
							  margin-right:10px;
						  }
						  #linkbk:hover{
							  background: red;
							  font-size: 30px;
							  color: white;
						  }
					</style>
			<?php }}?>
					</head>

  </body>
</html>

 <html>
   <head>
   <?php 
	   session_start();
    ?>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title> Login / Register</title>
	  <style>
	  body
	  {
		  background: #FFF5EE;
		  font-size: 20px;
		  font-weight: bold;
		  color: blue;
	  }
	  .login
	  {
          position: absolute;
          top: 150px;
		  left: 300px;
          background: snow;
		
	  }
	  .login:hover{
		  box-shadow: 2px 3px 7px 2px red; 		  
	  }
	.email
	{
	    position: relative;
        padding: 20px 20px 20px 20px;
	 }
		  #email{
             width: 300px;
             height: 50px;
             border: 2px solid white;
			  
		  }
		  
		  .email_error
		  {
             color: white;
             background: #CD5555;
             width: 400px;
             height: 25px;
             font-size: 20px
			 margin-left: 22px;
			 margin-right: 22px;
			 margin-top: -20px;
		
		  }
		  .password{
			  	 position: relative;
             padding: 20px 20px 20px 20px;
		  }
		  #password{
		     width: 300px;
             height: 50px;
             border: 2px solid white;
		  }
		  .password_error{
               color: white;
               background: #CD5555;
               width: 400px;
               height: 25px;
               font-size: 20px			  
		  }
		  .login_btn{
			  padding: 20px;
			  
		  }
		  #let{
			font-size: 20px;
		  font-weight: bold;
		  color: blue;  
		  }
	     #btn{
           border: 2px solid white;
           background: red;
           color: white;
           font-size: 20px;
           font-weight: bold;
           width: 100px;
           height: 50px;
	       margin-left: 20px;
		 }
		 #btn:hover{
			 background: green;
			 color: red;
			 transition: 0.5s;
			 transform: translate(10px);
		 }
		 #tit{
			position: absolute;
			top: 100px;
            left: 350px;
			font-size: 25px;
			font-family: system-ui;
			font-weight: bold;
		 }
		 #email:hover{
			 border: 2px solid blue;
			 
			 
		 }
		 #password:hover{
			 
			 border: 2px solid blue;
		 }
		 .sign{
			 position: fixed;
			 font-size: 25px;
			 top: 500px;
			 left: 300px;
			 
		 }
		 .sign a{
			 font-size: 25px;
		 }
		 .sign a:hover{
			 color: gold;
		 }
		 .email-signin{
			     position: absolute;
                 left: 750px;
                top: 250px;
		 }
		 .sendotp{
			    position: relative;
                left: 50px;
                top: 30px; 
		 }
		 #lgmail{
			     width: 300px;
                 height: 45px;
                border: 2px solid #178cc1;
		 }
		 #otp{
			 width:200px;
			 height:45px;
			 border:2px solid green;
			 box-shadow: inset -3px 3px 20px 0px green;
			 font-size: 25px;
			 font-family:system-ui;
		 }
		 #lgmail:hover{
			 box-shadow:2px 5px 13px 0px blue;
		 }
		 #vtp{
			     position: absolute;
                left: 800px;
               top: 150px;
	           color: black;
            font-family: -webkit-pictograph;
    font-size: x-large;
    background: darkorange;
		 }
		 #ins{
			font-size: 17px;
            color: darkred;
            background: #d89a9a;
            position: relative;
            top: 15px;
            border-radius: 5px; 
		 }
	   </style>
	</head>
	<body>
         <a href="userhome.php"><i class="fas fa-house"></i>&nbsp; Home</a>
		 <a href="log.php"><i class="fas fa-house"></i>&nbsp; back</a>
		 <span id="tit">LOGIN</span> 
	     <div class="login">
	         <form method="post" action="#">
			      <div class="email">
				      <label for="email">E-mail <br> <input type="email" id="email" placeholder="Enter E-mail" name="email">
				   </div>

		           <div class="password">
				      <label for="password">Password<br><input type="password" id="password" placeholder="Enter Passwordl" name="pass">
				   </div>

			      <div class="login_btn">
				      <input type="submit" name="login" id="btn" value="LOGIN">
			       </div>
				   
              </form>
		</div>
		<?php
		if($_POST){
		if(isset($_POST["login"]))
        {
           $user=$_POST["email"];
           $p=$_POST["pass"];
           $conn=mysqli_connect("localhost","root","","grocery");
           if(!$conn)
	           echo "Database error",mysqli_error($conn);
           $sql=mysqli_query($conn,"Select * from user_signup where customer_mail='".$user."'");
           echo mysqli_error($conn) ;
		   $r=mysqli_num_rows($sql);
		   echo $r;
           if($r==1)
           {
	           $rows = mysqli_fetch_assoc($sql);
		       $signeduser = $rows["customer_mail"];
		       $signedpassword = $rows["password"];
               if(($user == $signeduser)&&($p == $signedpassword)) 
               {  
				   $msg="loggedin ";
				   $_SESSION["user"] = $user; 
                }
               else
			   {
                   $msg = "Your password is invalid!"; 
                }
            }
			else
			{
				$msg = "your email not found";
			}
        }
	}
       else{
	      $msg = "Please enter valid credential to validate!";
        }  
		if(isset($msg)) 
		   echo $msg;  
?>
		<div class="sign">
		    <span>Don't have an account? <a href="customer_signup.php">Sign Up here..</a></span>
		</div>
		<span id="vtp"> LOGIN VIA OTP </span>
		<form method="post" action="">
		<div class="email-signin">
		     <input type="email" name="logmail" id="lgmail" placeholder="Enter Registered E-mail here"><br>
			    <span id="ins">Please Enter only email that you had Sign up.</span>
			 <div class="sendotp"><input type="submit" name="send" value="SendOtp" id="otp"></div>
		</div>
		</form>
	</body>
<?php
if(isset($_POST["send"])){
  $m=$_POST["logmail"];
  echo $m;
  $conn=mysqli_connect("localhost","root","","grocery");
  if(!$conn)
	   echo "Database error",mysqli_error($conn);
   $sql=mysqli_query($conn,"Select * from user_signup where customer_mail='".$m."'");
   $r=mysqli_num_rows($sql);
   if(($r>0)&&($r<2))
   {
	   while($row=mysqli_fetch_array($sql))
	   {
		   $user=$row["customer_mail"];
		}
   }
      if($user==$m) 
      {  
         $otp=rand(0,1000000);
         $to = $m;
         $subject  = 'ONE TIME PASSWORD VERIFICATION';
         $message  = "Hi, you just received an email from online provision store for that you had forgotten your password.
		              To change your password. Please enter the OTP.
		              Your OTP is:".$otp."";
         $headers  = 'From: stxavierscollegeprincipal@gmail.com' . "\r\n" .
            'MIME-Version: 1.0' . "\r\n" .
            'Content-type: text/html; charset=utf-8';
        if(mail($to, $subject, $message, $headers))
        {     echo "An otp is sent to your email";?>
			   <div class="otpv"><form action="#" method="post">
                  <input type="number" name="otpverify"id="otp"><br>
                 <input type="submit" name="verifyotp " id="verify">
              </form>
			  </div>
         </html>
		<?php }
        else
             echo"Email error try another option please"; 

	   }
    else{
	     echo"Please enter valid email!";
      }
}
if(isset($_POST["verifyotp"]))
{
	$v=$_POST["verifyotp"];
	echo $v;
	if($otp==$v)
	   echo "success";
	else 
	echo "success";

}
?> 

	       
<html>
   <head>
   <style>
   body{
	   background:snow;
   }
     .dash{
	 background: green;
    color: springgreen;
    text-align: center;
    margin-top: 20px;
    margin-left: 200px;
    margin-right: 200px;
    height: 60px;
    font-family: system-ui;
	  }
	  table{
		  border-collapse: collapse;
		  border: 3px solid ghostwhite;
		  background:snow;
	  }
	  td{
		  text-align:center;
		  vertical-align: center;
	  }
	  .tab{
		  width: 100%;
		  height: 100%;
		  margin-top: 30px;
		  border-radius: 3px solid ghostwhite;
		  background: snow;;
	  }
	  .btns{
		  border-radius: 5px;
		  background: yellow;
		  
	  }
	  .btns:hover{
		  background:#FFFF99;
		  border-color:blue;
	  }
	  td a{
		  text-decoration: none;
		  font-family: 'Lakki Reddy', cursive;
		  color:#ff6600;
		  font-size: 20px;
	  }
	  	  tr:nth-child(even){
		  background:snow;
		   font-size: 20px;
		  font-family: system-ui;
          color: green;
	  }
	  tr:nth-child(odd){
		  background:green;
		  font-size: 20px;
		  font-family: system-ui;
          color: snow;
	  }
   </style>
   </head>
   <?php
      $conn=mysqli_connect("localhost","root","","grocery");
      if(!$conn)
	      die("unable to connect with servers"); 
       if(isset($_GET["type"]) && ($_GET["type"]!=" "))
       {
	      $type=mysqli_real_escape_string($conn,$_GET["type"]);
          if($type=="status")
          {
		    $operation=mysqli_real_escape_string($conn,$_GET['operation']);
		    $id= mysqli_real_escape_string($conn,$_GET['id']);
		    if($operation=="active")
		       $status=1;
	        else
		       $status=0;
	       $update=mysqli_query($conn,"update ordering_table set ordering_status='$status' where ordering_id = '$id'");
			
	      }
   }
	$sql=mysqli_query($conn,"Select * from ordering_table where ordering_status=0");
   ?>
<body>
	       <div class="dash">
		       <h1> LIST OF ORDERS </h1>
		   </div>
		   <div class="tab">
		      <table width="100%" cellspacing="20px" cellpadding="20px" border="2px solid grey" >
			     <tr>
				      <th> ORDER_ID</th>
				      <th> CUSTOMER_ID </th>
				      <th> PURCHASE AMOUNT </th>
                      <th> ORDER DATE</th>
                      <th> ORDER TIME</th>
                      <th> ACTION </th>
				</tr>
				<tr>
				      <?php while($r=mysqli_fetch_assoc($sql))
					  { ?>
                      <td><?php echo $r["ordering_id"]?></td>
				      <td> <?php echo $r["customer_id"]?> </td>
				      <td><?php echo $r["price"]?></td>
					  <td><?php echo $r["ordering_date"]?></td>
					  <td><?php echo $r["ordering_time"]?></td>
				      <td> <div class="btns">
				               <?php
				                  if($r['ordering_status']==1)
				                      echo "<a href='?type=status&operation=Deactive&id=".$r['ordering_id']."'>APPROVED</a>";
				                  else
			                          echo"<a href='?type=status&operation=active&id=".$r['ordering_id']."'>PENDING</a>";
					           ?>
					        </div>
					     </td>
				</tr>
			<?php }?>
			</table>
			</div>
		 </body>
	</html>
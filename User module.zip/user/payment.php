<html>
   <head>
       <title> Payment </title>
   </head>
   <body>
     <h1> PAYMENT METHOD </h1>
     <form method="POST" action="#">
        <input type=radio name="payment" value="pay using card">PAYMENT USING CARD<br>
       <b> Enter Card details if you select card method</b>
        CARD NUMBER<input type="text" name="Cardnumber" maxlength=14 placeholder="xxxx-xxxx-xxxx"><br>
        CARD DATE<input type="month" name="cardDate" id="cardDate"  /><br>
        <input type=radio name="payment" value="cash on delivery">CASH ON DELIVERY<br>
        <input type="submit" name="placeorder" value="placeorder">
    </form>
    </body>
 <?php
 session_start();
 $conn = mysqli_connect("localhost","root","","grocery");
if (!$conn){
    die("Database error");
}


      $msg="";
     if(isset($_POST["payment"])){
         $paymethod = $_POST["payment"];
         
         if($paymethod == "pay using card")
          {
            $cardnumber=$_POST["Cardnumber"];
         $cardDate=$_POST["cardDate"];
         echo $cardnumber,$cardDate;
         if(($cardDate=="")|| ($cardnumber=="")) {
             $msg ="Please enter the credit card expiration date.";
             echo "1";
        }   
      /*   else {
              if (!preg_match("/^([0-9]{4})$/", $cardnumber)) {
                   $msg="The card number format is not correct!";
                   echo "1";}
              if (!preg_match("/^(0[1-9]|1[0-2])[-][0-9]{2}$/", $cardDate)) {
                   $msg= "The expire date format is not correct!";echo "1";}

        }*/
        if($msg == ""){
            $currentDate = date('m/y/d');
            echo $currentDate;
            $exp = date_format(date_create($cardDate),'m/y/d');
         print_r($exp);
           // echo $diff;
            //echo $current;
             //$diff= date_diff($exp,$currentDate);

             //print_r($diff);
            if (1) {
                echo "card accepted";
                         $cname= $_SESSION["user"];
      $q=mysqli_query($conn,"select customer_id from user_signup where customer_mail='".$cname."'");
      $details= mysqli_fetch_assoc($q);
      $cid=$details["customer_id"];
      foreach($_SESSION["shopping_cart"] as $product){
      $productid= $product["code"];
      $name= $product["name"];
      $quant=$product["quantity"];
      $date= date("Y.m.d");
      $price=$_GET["tp"];
      
      date_default_timezone_set("Asia/Calcutta");
      $time=date("H:i:s");
               $s=mysqli_query($conn,"Insert into ordering_table(customer_id,product_id,price,ordering_time,ordering_date,quantity,payment_method) 
              values('$cid','$productid','$price','$time','$date','$quant','$paymethod')");
               include("productupdate.php");
               $msg="Order is placed";
               echo $msg;
      }
            }
            else{
                $msg= "Credit card has expired";
               // echo "card accepted";
            }
          
        }
        else{
            echo "error";
        }
}
else 
{
    echo("Second, eh?");
}
}
?>
<html>
   <head>
   </head>
   <body>
      <?php 	
      $conn=mysqli_connect("localhost","root","","grocery");
      if(!$conn)
	      die("unable to connect with servers"); 
      $sql=mysqli_query($conn,"Select * from ordering_table where ordering_status=1");?>
      <div class="dash">
		       <h1> LIST OF ORDERS </h1>
		   </div>
		   <div class="tab">
		      <table width="100%" cellspacing="20px" cellpadding="20px" border="2px solid grey" >
			     <tr>
				      <th> ORDER_ID</th>
				      <th> CUSTOMER_ID </th>
				      <th> PURCHASE AMOUNT </th>
                      <th> ORDER DATE</th>
                      <th> ORDER TIME</th>
                      <th> ACTION </th>
				</tr>
				<tr>
				      <?php while($r=mysqli_fetch_assoc($sql))
					  { ?>
                      <td><?php echo $r["ordering_id"]?></td>
				      <td> <?php echo $r["customer_id"]?> </td>
				      <td><?php echo $r["price"]?></td>
					  <td><?php echo $r["ordering_date"]?></td>
					  <td><?php echo $r["ordering_time"]?></td>
				      <td> <div class="btns">
				               <?php
				                  if($r['ordering_status']==1)
				                      echo "<a href='?type=status&operation=Deactive&id=".$r['ordering_id']."'>APPROVED</a>";
				                  else
			                          echo"<a href='?type=status&operation=active&id=".$r['ordering_id']."'>PENDING</a>";
					           ?>
					        </div>
					     </td>
				</tr>
			<?php }?>
			</table>
			</div>
    </body>
</html>
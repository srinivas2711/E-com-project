<html>
 <head>
     <link rel="stylesheet" href="style2.css">
	 <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width,initial-scale=1.0">
  </head>
  <body>
          <div class="title">
		        <h1 class="h"> LIST FOR ADMIN ACCESS </h1>
		   </div>
	       <table>
              <tr>
                  <td class="t"><div class="cate">
	                  <a href="categories.php">categories Master </a>
		              </div>
				   </td>
				  <td class="t"><div class="cate">
	                  <a href="products.php">Product Master </a>
		              </div>
				   </td>
			       <td class="t"><div class="cate">
	                  <a href="orders.php">Order Master </a>
		              </div>
				   </td>
			   </tr>
			</table>
	</body>
 </html>